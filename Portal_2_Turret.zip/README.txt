                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3394464
Portal 2 Turret by Novachris is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

*************************  UPDATED *************************
v4 parts - revised body, wings, pitch frame - reduced the bridging in the body which required revised wings and pitch frame.  v4 of rear leg is stretched a little to make more room for a connector.  The "leg-rear test" is an option to replace proper rear leg, but allows one to easily plug in the mini-usb connector to power and upload the turret.  Use these along with v3 or highest revision of parts.

v3 of body incorporates larger eye, more similar to game character.

******************************************************************

This Christmas, I decided to design and build a working, talking Portal turret gun from the game Portal 2. For me, this was an exercise of properly modelling the entire assembly in Fusion 360 first, before building anything. This design uses an Arduino Nano, an MP3 player chip, distance sensor, servos, LEDs and 3D printed parts.

The goal here was to make it move in 3 "axes", with spoken sound from the game and LED's to simulate firing.

- Open the "wings" if it senses someone in front. Use a crank mechanism with sliders, just because.

- If the person is still there after opening, fire until they drop. LED's and machine gun sound.

- If the person is no longer there, run a little scanning search routine.

- Close up and go to sleep until someone else comes along.

- Use Portal turret sounds and voices from the game.

I took some liberties in the design, trying to make it appreciably the same as the one seen in the game, but functional and printable. With some basic sketches found online, I started modelling and planning...

The sounds are stored on a microSD card, which is accessible from the back side so that sounds may be updated or changed later. It is inline with the black infill strip, making it essentially invisible once installed. 18 individual expressions and sounds used in this go-round.

The lidar sensor (time-of-flight) is on a chip with a rectangular profile. This sensor is nearly invisible from the front once assembled.

The full project and code are available on Instructables.com
https://www.instructables.com/id/Portal-2-Turret-Gun/


# Print Settings

Printer Brand: Prusa
Printer: Prusa Mk2
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 20%
Filament_brand: Generic
Filament_color: White or Blue, and Black
Filament_material: PLA

# Post-Printing

No post printing, other than some cleanup of the black infill strip channel and chasing the slider holes for the sliders (nails).

Recommend using a 2mm brim, one layer thick to help with the printing of the body and wings.  Easy clean up afterwards, with better result.

# How I Designed This

The design started from sketches found online. Using these images as canvases, I started sketching the outlines of the 3 views. Then it was a matter of extruding them into 3D, then shelling the general shape and making cuts. All electronics were built in Fusion as components that were inserted and placed where I thought it would make sense. Driving parameters were:

    Arduino nano had to have connector accessible for updating once fully assembled
    MicroSD card had to be accessible in the same manner, and ideally invisible once installed
    Time-of-flight sensor should be invisible as well
    A 2.1mm electrical connector for power at the back
    Printed parts to be as large as possible (not a lot of little pieces)
    Print with no supports

After components (Nano, other chips, servos) were added to the basic shape, they were moved around and positioned as required, and the supporting structures were built to support them inside the shell.

The wing opening mechanism was a crank and slide mechanism. Why? Because I wanted to use a crank mechanism, that's why! This added some complications, but it also had a benefit; once the geometry was determined, operational repeatability would be ensured and the min and max limits were pretty much guaranteed.

Once the entire model was built and I was confident that it would work, and could be built (printed) and assembled, I went ahead and printed out the parts and built a prototype. Once that worked out, I went back to the model and made some tweaks to improve appearance and assemblability (is that a word?). This model is what came of those changes.

This was pretty taxing, as there really aren't many boxy shapes in this thing, and it closes up pretty tightly, with no real access for tweaking once put together. I learned quite a bit on this project, such as using embedded components within other components. This made manipulating and keeping sub-assemblies linked for quick access. In the end, it was worth the effort!

You can view and comment on the design using this link: https://a360.co/2SiUWKm


<iframe src="//www.youtube.com/embed/cdo-GNOyY10" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/KV9u3x8NS2w" frameborder="0" allowfullscreen></iframe>